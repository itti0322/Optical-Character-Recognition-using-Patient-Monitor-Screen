# -*- coding: utf-8 -*-
"""
Created on Fri Jun 11 15:58:53 2021

@author: Irtza
"""

def irtza():
    print('Hello')
    return

def aaa():
    print("Hi")
