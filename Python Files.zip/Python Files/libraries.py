"""
Created on Fri Jun 11 16:03:11 2021

@author: Irtza
"""
def import_libraries():
    import matplotlib.pyplot as plt
    import numpy as np
    import cv2
    import os
    import easyocr
    from PIL import Image
    import glob
    import promptlib
    from time import sleep
    from tqdm.auto import tqdm
    from progress.bar import Bar
    import glob
    import re
    from collections import OrderedDict
    import string
    import csv
    import pandas as pd
    reader=easyocr.Reader(['en'])
    import time

    return
